function a=activy(x)
a=1.0*(x-0.0);

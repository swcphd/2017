function a=activ(x)
global xth xgain xsat;
  %a=min(1,max(0,x));
%a=1.0*(x-1.0);
a=xgain*max(0,x-xth);
a=min(a, xgain*(xsat-xth));
%a = a +xth;

% --- This is written by Li Zhaoping, Nov. 14, 2016.
%
%---- home work to try a simplified lamprey locomotion, with just six neurons for one 
%-----spinal cord segment, 3 neurons for each hemisegment. These three neuron types are: E, L, C neurons, see paper by Zhaoping, Lewis, Scarpetta 2004 "Mathematical analysis and simulations of the neural circuit for locomotion in lamprey. Physical Review Letters 92, 198106 " for details.
% --- this homework is a simplified homework version of the materials in that paper.




%%%%%%%%
%--- The six neurons will be labeled as El, Ll, Cl for the E, L, C neurons in the 
%---------left hemi-segment,
%---- Er, Lr, Cr for the three neurons in the right hemi-segment.  
%
%--- the external inputs to the six neurons are denoted as I_El, I_Ll, I_Cl, I_Er, I_Lr, I_Cr. 
%
%----
%

%%%%%%%%%%%%%% Please do the following in the homework
%%%%%%%%% (1) run this program, see how things work.





clear all;
%close all;

global xth xgain xsat;

xth=0.5;   %--- threshold membrane for neural response
xgain=1.0;  %--- gain of the neural response beyond the threshold
xsat =1.5;  %--- the saturation level of the membrane potential for highest response.


%----- neural connections between E, L, C cells, using notations as those in Zhaoping et al 2004.
B = 8.9;
A = 1;
H = 15.5;
W = 0;
Q = 2;
%
K=A;
J=W;


dt = 0.01; %--- time step size
Nt=3000; %--- number of time steps.

%--- record of neural responses over the time period
R_El=zeros(Nt, 1);
R_Ll=zeros(Nt, 1);
R_Cl=zeros(Nt, 1);
R_Er=zeros(Nt, 1);
R_Lr=zeros(Nt, 1);
R_Cr=zeros(Nt, 1);


%--- initial membrane potentials for the neurons, I give three examples of the initial conditions, you can comment out the ones you do not need. 
% initial condition option 1: this initial condition has non-zero left-right in-phase and non-zero left-right anti-phase, 
%---- one should see good antiphase oscillation emerges, in-phase oscillate decays.
El=0;
Ll=0;
Cl=0.5;
Er=0;
Lr=0;
Cr=0;

%%%%%%%%%%% initial condition option 2: initial membrane potential with zero anti-phase, non-zero in-phase, you will see no oscillations unless you inject noise into the system
%El=1.0;
%Ll=1.0;
%Cl=0.5;
%Er=1.0;
%Lr=1.0;
%Cr=0.5;



%%%%%%%%%%%% initial condition option 3: initial membrane potential with zero in-phase, and non-zero antiphase, you will see nice oscillations in antiphase.
%El=1.0;
%Ll=1.0;
%Cl=0.5;
%Er=-1.0;
%Lr=-1.0;
%Cr=-0.5;

%%%%%%%%%%% Set the external inputs from the brainstem to the six neurons in CPG. I give two examples of such external inputs, you can comment out one.
%---- First option for the external input --- This external inputs can make CPG oscillate
I_El=0.5;
I_Ll=0.5;
I_Cl=5.45;
I_Er=0.5;
I_Lr=0.5;
I_Cr=5.45;

%---- Second option for the external input --- this external inputs make no CPG oscillations.
%---- zero 
%I_El=0.0;
%I_Ll=0.0;
%I_Cl=0.0;
%I_Er=0.0;
%I_Lr=0.0;
%I_Cr=0.0;



%----- neural dynamics, following equations in Zhaoping et al 2004, except that there are only six neurons for one segment of the CPG.

for t=1:Nt  %--- _dot means d/dt  time derivative
	%--- time derivative of the C cells
	Cl_dot = (-Cl - B*activ(Cr) + Q*activy(El) - H*activy(Ll) + I_Cl);
 	Cr_dot = (-Cr - B*activ(Cl) + Q*activy(Er) - H*activy(Lr) + I_Cr);
	%--- time derivative of the L cells
    	Ll_dot = (-Ll - A*activ(Cr) +  W*activy(El) + I_Ll);
    	Lr_dot = (-Lr - A*activ(Cl) +  W*activy(Er) + I_Lr);
	%--- time derivative of the E cells
    	El_dot = (-El + J*activy(El) - K*activ(Cr)  + I_El);
    	Er_dot = (-Er + J*activy(Er) - K*activ(Cl)  + I_Er);
	%----
	Cl  = Cl + Cl_dot*dt;
	Cr  = Cr + Cr_dot*dt;
	%
	El  = El + El_dot*dt;
	Er  = Er + Er_dot*dt;
	%
	Ll  = Ll + Ll_dot*dt;
	Lr  = Lr + Lr_dot*dt;
	%
	R_Cl(t) = Cl; 
	R_Cr(t) = Cr; 
	%
	R_El(t) = El; 
	R_Er(t) = Er; 
	%
	R_Ll(t) = Ll; 
	R_Lr(t) = Lr;
end

C_plus = R_Cl + R_Cr; 
E_plus = R_El + R_Er; 
L_plus = R_Ll + R_Lr; 
%
C_minus = R_Cl - R_Cr; 
E_minus = R_El - R_Er; 
L_minus = R_Ll - R_Lr; 


%%%%%%%%%%%%%%%55
Ntt =Nt;
TimeSequence = 1:Ntt;
time_list = TimeSequence*dt;

%%%%%%%%%%%%%%%%%% figure(1) plots out the neural membrane potentials as functions of time
figure(1); clf; 
subplot(2, 3, 1);
plot(time_list,  R_Cl(1:Ntt), 'r');  hold on;
title('Left C (red)');
subplot(2, 3, 2);
plot(time_list,  R_Ll(1:Ntt), 'b');  hold on;
title('Left L (blue)');
subplot(2, 3, 3);
plot(time_list,  R_El(1:Ntt), 'g');  hold on;
title('Left E (green)');
%
subplot(2, 3, 4);
plot(time_list,  R_Cr(1:Ntt), 'r');  hold on;
title('Right C (red)');
subplot(2, 3, 5);
plot(time_list,  R_Lr(1:Ntt), 'b');  hold on;
title('Right L (blue)');
subplot(2, 3, 6);
plot(time_list,  R_Er(1:Ntt), 'g');  hold on;
title('Right E (green)');


%%%%%%%%%%%% figure(2) plots the left-right anti-phase and left-right in-phase modes of the neural activities.
figure(2);  clf; 
subplot(2, 3, 1); 
plot(time_list,  C_minus(1:Ntt), 'r');  hold on;
title('Left-right antiphase mode: C (red)');
subplot(2, 3, 2); 
plot(time_list, L_minus(1:Ntt), 'b');  hold on;
title('Left-right antiphase mode: L (blue)');
subplot(2, 3, 3); 
plot(time_list, E_minus(1:Ntt), 'g');  hold on;
title('Left-right antiphase mode: E (green)');
%
subplot(2, 3, 4); 
plot(time_list, C_plus(1:Ntt), 'r');  hold on;
title('Left-right  in-phase mode: C (red)');
subplot(2, 3, 5); 
plot(time_list, L_plus(1:Ntt), 'b');  hold on;
title('Left-right  in-phase mode: L (blue)');
subplot(2, 3, 6); 
plot(time_list, E_plus(1:Ntt), 'g');  hold on;
title('Left-right  in-phase mode: E (green)');


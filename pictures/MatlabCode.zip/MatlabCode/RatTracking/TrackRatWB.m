function [I_row, I_col,Original] = TrackRatWB(Movie,NormalizingFrame,FrameNumber)
    BinaryThreshold=99.5;
    Original=Movie(:,:,FrameNumber);
    Frame=abs(double(Original)-NormalizingFrame);
    BlurredFrame=imgaussfilt(Frame,5);
    BinaryFrame = imbinarize(BlurredFrame,0.8*prctile(Frame(:),BinaryThreshold));
    BinaryFrame2 = 1-imbinarize(Original,50/255);
    BinaryFrameCombined=BinaryFrame.*BinaryFrame2;
    DistanceTransformedFrame=bwdist(1-BinaryFrameCombined);
    [~,I] = max(DistanceTransformedFrame(:));
    [I_row, I_col] = ind2sub(size(DistanceTransformedFrame),I);
end


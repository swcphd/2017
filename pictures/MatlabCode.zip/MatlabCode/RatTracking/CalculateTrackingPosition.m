function [I_rows,I_cols] = CalculateTrackingPosition(Movie,StartFrame,EndFrame,BackgroundColor,Display)
    
    I_rows=zeros(1,EndFrame-StartFrame+1);
    I_cols=zeros(1,EndFrame-StartFrame+1);
    for(i=StartFrame:EndFrame)
        Start=max(StartFrame,i-2000);
        End=min(EndFrame,i+2000);
        averagedMovie=mean(Movie(:,:,Start:round(min((EndFrame-StartFrame+1)/80,50)):End),3);
        if(strcmp(BackgroundColor,'White'))
            [I_row, I_col]=TrackRatWB(Movie,averagedMovie,i);
        elseif(strcmp(BackgroundColor,'Black'))
            [I_row, I_col]=TrackRatBB(Movie,averagedMovie,i);
        end
            
        I_rows(i-StartFrame+1)=I_row;
        I_cols(i-StartFrame+1)=I_col;
    end

    if(Display==1)
        figure

        yyaxis left
        plot((StartFrame:EndFrame-1)/3000,MeanFilter(0.470/530*50*(sqrt(diff(I_rows).^2+diff(I_cols).^2)),3),'b','linewidth',2);
        xlabel('Time (min)','fontsize',18);
        ylabel('Speed (m/s)','fontsize',18);
        set(gca,'fontsize',16)
        set(gca,'YColor','b');

        yyaxis right
        plot((StartFrame:EndFrame-1)/3000,0.470/530*cumsum(sqrt(diff(I_rows).^2+diff(I_cols).^2)),'r','linewidth',2);
        xlabel('Time (min)','fontsize',18);
        ylabel('Distance (m)','fontsize',18);
        set(gca,'fontsize',16)
        set(gca,'YColor','r');
        grid on;
        xlim(([StartFrame,EndFrame-1])/3000);
    end
end


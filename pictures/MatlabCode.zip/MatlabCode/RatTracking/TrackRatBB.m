function [I_row, I_col,Original] = TrackRatBB(Movie,NormalizingFrame,FrameNumber)
    BinaryThreshold=99.5;
    Original=Movie(:,:,FrameNumber);
    Frame=abs(double(Original)-NormalizingFrame);
    BlurredFrame=imgaussfilt(Frame,5);
    BinaryFrame = imbinarize(BlurredFrame,0.8*prctile(Frame(:),BinaryThreshold));
    DistanceTransformedFrame=bwdist(1-BinaryFrame);
    [~,I] = max(DistanceTransformedFrame(:));
    [I_row, I_col] = ind2sub(size(DistanceTransformedFrame),I);
end


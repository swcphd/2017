function [HeatMap] = CreateTrackingHeatMap(XBins,YBins,ImageSizeX,ImageSizeY,BlurrFactor,I_rows,I_cols)
    HeatMap=zeros(XBins,YBins);
    for(i=1:XBins)
        for(j=1:YBins)
            HeatMap(i,j)=size(find(I_cols>(i-1)*ImageSizeX/XBins&I_cols<=i*ImageSizeX/XBins&I_rows>(j-1)*ImageSizeY/YBins&I_rows<=j*ImageSizeY/YBins),2);
        end
    end
    HeatMap=imgaussfilt(HeatMap,BlurrFactor);
end


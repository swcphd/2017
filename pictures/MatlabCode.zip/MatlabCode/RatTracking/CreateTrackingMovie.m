function [] = CreateTrackingMovie(OutputFileName,Movie,ComputingStartFrame,DisplayStartFrame,EndFrame,XBins,YBins,ImageSizeX,ImageSizeY,BlurrFactor,SpeedFactor,BackgroundColor) 
    h=figure('rend','painters','pos',[50 50 1250 300]);
    vidObj = VideoWriter(OutputFileName);
    vidObj.FrameRate=50*SpeedFactor;
    vidObj.Quality=100;
    open(vidObj);
            
    [I_rows,I_cols] = CalculateTrackingPosition(Movie,ComputingStartFrame,EndFrame,BackgroundColor,0);
        
    for t=DisplayStartFrame:EndFrame
        subplot(1,2,1);
        imshow(Movie(:,:,t));
        hold on;
        plot(I_cols(t-ComputingStartFrame+1),I_rows(t-ComputingStartFrame+1),'r*','markersize',10);
        hold off;
        title(['Time: ',sprintf('%0.0f',floor((t-ComputingStartFrame+1-1)/3000)),' min ',sprintf('%0.2f',mod((t-ComputingStartFrame+1-1)/50,60)),' s'],'fontsize',18);
        set(gca,'fontsize',16);

        subplot(1,2,2);
        I_cols2=I_cols(1:t-ComputingStartFrame+1);
        I_rows2=I_rows(1:t-ComputingStartFrame+1);
        HeatMap = CreateTrackingHeatMap(XBins,YBins,ImageSizeX,ImageSizeY,BlurrFactor,I_rows2,I_cols2);
        imshow(HeatMap'/50,[0 (500/94000*(t-ComputingStartFrame+1)+10)/50], 'InitialMagnification', 2000)
        c=colorbar;
        c.Label.String='Time spent in bin (s)';
        c.Label.FontSize=16;
        colormap(gca,'hot')
        title(['Time: ',sprintf('%0.0f',floor((t-ComputingStartFrame+1-1)/3000)),' min ',sprintf('%0.2f',mod((t-ComputingStartFrame+1-1)/50,60)),' s'],'fontsize',18);
        set(gca,'fontsize',16);

        frame = getframe(h);
        writeVideo(vidObj,frame);
    end
    close(vidObj); 
end


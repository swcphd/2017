function [FilteredArray] = PercentilFilter(Array,Percentil,WindowSize,PaddingMode)

if(PaddingMode==1)
    if(size(Array,2)>size(Array,1))
        ExpandedArray=[fliplr(Array),Array,fliplr(Array)];
    else
        ExpandedArray=[fliplr(Array'),Array',fliplr(Array')]';
    end
elseif(PaddingMode==0)
    if(size(Array,2)>size(Array,1))
        ExpandedArray=[NaN*fliplr(Array),Array,NaN*fliplr(Array)];
    else
        ExpandedArray=[NaN*fliplr(Array'),Array',NaN*fliplr(Array')]';
    end
end

ArrayLength=max(size(Array));
FilteredArray=zeros(size(Array));

for(i=(ArrayLength+1):(2*ArrayLength))    
   FilteredArray(i-ArrayLength)=prctile(ExpandedArray((i-floor(WindowSize/2)):(i+floor(WindowSize/2))),Percentil);
end

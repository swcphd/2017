function [Movie] = ExtractAvi(ImportFileName,SavingFileName,UsedFrameArray,CroppingParameters)
    h = waitbar(0,'Initializing waitbar...');
    packages=2000;
    obj=mmread(ImportFileName,1);
    if(isempty(UsedFrameArray))
        nFrames=round(obj.rate*obj.totalDuration)+1;
        StartFrame=1;
        EndFrame=nFrames;
    else
        nFrames=UsedFrameArray(2)-UsedFrameArray(1)+1;
        StartFrame=UsedFrameArray(1);
        EndFrame=UsedFrameArray(2);
    end
    Width=obj.width;
    Height=obj.height;
    clear obj;
    if(isempty(CroppingParameters))
        Movie=(zeros(Height,Width,nFrames,'uint8'));
    else
        Movie=(zeros(CroppingParameters(2,2)-CroppingParameters(2,1)+1,CroppingParameters(1,2)-CroppingParameters(1,1)+1,nFrames,'uint8'));
    end
    for(i=1:ceil(nFrames/packages))
        waitbar((i-1)/ceil(nFrames/packages),h,['Loading movie to Matlab: ',num2str((i-1)/ceil(nFrames/packages)*100,2),'%']);
        obj=mmread(ImportFileName,StartFrame+packages*(i-1):min(packages*i+StartFrame-1,EndFrame));
        for(j=1:(min(packages*i,nFrames)-packages*(i-1)))
            if(isempty(CroppingParameters))
                Movie(:,:,j+(i-1)*packages)=uint8(obj.frames(j).cdata(:,:,1));
            else
                Movie(:,:,j+(i-1)*packages)=uint8(obj.frames(j).cdata(CroppingParameters(2,1):CroppingParameters(2,2),CroppingParameters(1,1):CroppingParameters(1,2),1));
            end
        end
        clear obj;
    end
    
    if(~isempty(SavingFileName))
        waitbar(1,h,'Saving...');
        save(SavingFileName,'Movie','-v7.3');
    end
    close(h);
end

